package co.edu.javeriana.ingsoft.quemadiaria.principiossolid.c.servicios.services;

import co.edu.javeriana.ingsoft.quemadiaria.principiossolid.c.servicios.dto.RegistroUsuarioDTO;
import co.edu.javeriana.ingsoft.quemadiaria.principiossolid.c.servicios.dto.ResponseDTO;

public class RegistroUsuarioService {

    public ResponseDTO<String> registrarUsuario(RegistroUsuarioDTO registroUsuarioDTO) {
        return null;
    }
}
