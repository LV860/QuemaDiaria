package co.edu.javeriana.ingsoft.quemadiaria.principiossolid.e.interfaces.main;

public class Menu {

}
