package co.edu.javeriana.ingsoft.quemadiaria.e.interfaces;

public interface Command {
    void execute();
}
