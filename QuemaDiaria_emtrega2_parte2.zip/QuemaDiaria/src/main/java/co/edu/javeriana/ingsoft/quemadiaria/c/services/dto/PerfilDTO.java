package co.edu.javeriana.ingsoft.quemadiaria.c.services.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class PerfilDTO {
    private int altura;
    private int peso;
    private String complexion;
    private String objetivo;
}
