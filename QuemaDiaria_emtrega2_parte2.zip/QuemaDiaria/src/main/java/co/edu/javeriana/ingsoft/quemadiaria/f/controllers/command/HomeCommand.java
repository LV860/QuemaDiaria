package co.edu.javeriana.ingsoft.quemadiaria.f.controllers.command;

import co.edu.javeriana.ingsoft.quemadiaria.MenuLogin;
import co.edu.javeriana.ingsoft.quemadiaria.e.interfaces.Command;

import java.io.IOException;

public class HomeCommand implements Command {
    private MenuLogin mainApp;

    public HomeCommand(MenuLogin mainApp) {
        this.mainApp = mainApp;
    }

    @Override
    public void execute() {
        try {
            mainApp.showHomeScreen();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
